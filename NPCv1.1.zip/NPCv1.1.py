#welcome to the Non Player Creator or NPC. Good luck on your adventures!

import random
import sys
from pathlib import Path
from tkinter import *
from tkinter import Entry

root = Tk()
root.title("NPC")
root.geometry("900x400")

def nameclick():
    global character_name
    continue_button = Button(root, text="continue", command=match_function, padx=50)
    continue_button.grid(row=16, column=3, columnspan=2)
    character_name.get()
    return character_name


def match_function():
    global Strength
    global Dexterity
    global Constitution
    global Intelligence
    global Wisdom
    global Charisma
    match int(Strength.get()):
        #fixed an issue with abs, had it set to abs not -absNPCv1.0.py
        case 8 | 9:
            STR_bonus = -abs(1)
        case 10 | 11:
            STR_bonus = 0
        case 12 | 13:
                STR_bonus = 1
        case 14 | 15:
                STR_bonus = 2
        case 16 | 17:
                STR_bonus = 3
        case 18 | 19:
                STR_bonus = 4
        case _:
                STR_bonus = 5
    match int(Dexterity.get()):
        case 8 | 9:
                DEX_bonus = -abs(1)
        case 10 | 11:
                DEX_bonus = 0
        case 12 | 13:
                DEX_bonus = 1
        case 14 | 15:
                DEX_bonus = 2
        case 16 | 17:
                DEX_bonus = 3
        case 18 | 19:
                DEX_bonus = 4
        case _:
                DEX_bonus = 5
    match int(Constitution.get()):
        case 8 | 9:
            CON_bonus = -abs(1)
        case 10 | 11:
            CON_bonus = 0
        case 12 | 13:
            CON_bonus = 1
        case 14 | 15:
            CON_bonus = 2
        case 16 | 17:
            CON_bonus = 3
        case 18 | 19:
            CON_bonus = 4
        case _:
            CON_bonus = 5
    match int(Intelligence.get()):
        case 8 | 9:
                INT_bonus = -abs(1)
        case 10 | 11:
                INT_bonus = 0
        case 12 | 13:
                INT_bonus = 1
        case 14 | 15:
                INT_bonus = 2
        case 16 | 17:
                INT_bonus = 3
        case 18 | 19:
                INT_bonus = 4
        case _:
                INT_bonus = 5
    match int(Wisdom.get()):
        case 8 | 9:
                WIS_bonus = -abs(1)
        case 10 | 11:
                WIS_bonus = 0
        case 12 | 13:
                WIS_bonus = 1
        case 14 | 15:
                WIS_bonus = 2
        case 16 | 17:
                WIS_bonus = 3
        case 18 | 19:
                WIS_bonus = 4
        case _:
                WIS_bonus = 5
    match int(Charisma.get()):
        case 8 | 9:
                CHA_bonus = -abs(1)
        case 10 | 11:
                CHA_bonus = 0
        case 12 | 13:
                CHA_bonus = 1
        case 14 | 15:
                CHA_bonus = 2
        case 16 | 17:
                CHA_bonus = 3
        case 18 | 19:
                CHA_bonus = 4
        case _:
                CHA_bonus = 5
#hope this spellcasting ability match is idiot proof
    match spellcasting_ability_input:
        case "Intelligence" | "intelligence" | "INT" | "int":
            spell_attack = INT_bonus + int(proficiency_bonus.get())
            spell_save_DC = 8 + INT_bonus + int(proficiency_bonus.get())
        case "Wisdom" | "wisdom" | "WIS" | "wis":
            spell_attack = WIS_bonus + int(proficiency_bonus.get())
            spell_save_DC = 8 + WIS_bonus + int(proficiency_bonus.get())
        case "Charisma" | "charisma" | "CHA" | "cha":
            spell_attack = CHA_bonus + int(proficiency_bonus.get())
            spell_save_DC = 8 + CHA_bonus + int(proficiency_bonus.get())
        case _:
            spell_attack = INT_bonus + int(proficiency_bonus.get())
            spell_save_DC = 8 + INT_bonus + int(proficiency_bonus.get())
    hp_list = []
    for i in range(0, int(hit_die_total.get())):
        x = random.randint(1, int(hit_die.get())) + CON_bonus
        hp_list.append(x)
    hp = sum(hp_list)
    ac = 10 + DEX_bonus + int()
    Strength_attack = STR_bonus + int(proficiency_bonus.get())
    Dexterity_attack = DEX_bonus + int(proficiency_bonus.get())
    path = Path()
    with open("my_character.txt", "w+" ) as f:
        f.writelines('''

    Your NPC is Complete!

    ''' + character_name.get() + '''
    ''' +
    "HP: " + str(hp) + '''
    ''' +

    "AC: " + str(ac) + '''
    ''' +

    "STR: " + (Strength.get()) + " STR Bonus: " + str(STR_bonus) + """
    """ +

    "DEX: " + (Dexterity.get()) + " DEX Bonus: " + str(DEX_bonus) + '''
    ''' +

    "CON: " + (Constitution.get()) + " CON Bonus: " + str(CON_bonus) + '''
    ''' +

    "INT: " + (Intelligence.get()) + " INT Bonus: " + str(INT_bonus) + '''
    ''' +

    "WIS: " + (Wisdom.get()) + " WIS Bonus: " + str(WIS_bonus) + '''
    ''' +

    "CON: " + (Charisma.get()) + " CHA Bonus: " + str(CHA_bonus) + '''
    ''' +

    "Strength Attack Bonus: " + str(Strength_attack) + '''
    ''' +

    "Dexterity Attack Bonus: " + str(Dexterity_attack) + '''
    ''' +

    'Spell Save DC: ' + str(spell_save_DC) + '''
    ''' +

    'Spell Attack Bonus: ' + str(spell_attack))
#someone put me out of my misery XD

#placing buttons and entries in no particular order cause I'm a fucking mess
hit_die = Entry(root, width=50)
hit_die.grid(row=8, column=3, columnspan=2)
hit_die.insert(0, "What's your hit die type in #?")
hit_die_total = Entry(root, width=50)
hit_die_total.grid(row=9, column=3, columnspan=2)
hit_die_total.insert(0, "Total # of hit dice?(LVL)")
ac_bonus = Entry(root, width=50)
ac_bonus.grid(row=10, column=3, columnspan=2)
ac_bonus.insert(0, "Bonus to AC OTHER than Dex bonus")
spellcasting_ability_input = Entry(root, width=50)
spellcasting_ability_input.grid(row=11, column=3, columnspan=2)
spellcasting_ability_input.insert(0, "Spellcasting Ability")
proficiency_bonus = Entry(root, width=50)
proficiency_bonus.grid(row=12, column=3, columnspan=2)
proficiency_bonus.insert(0, "Prof. Bonus")
character_name = Entry(root, width=50)
character_name.grid(row=3, column=1)
character_name.insert(0, "NPC Name")
AS_1 = random.randint(8, 18)
AS_2 = random.randint(8, 18)
AS_3 = random.randint(8, 18)
AS_4 = random.randint(8, 18)
AS_5 = random.randint(8, 18)
AS_6 = random.randint(8, 18)
assign_scores_label = Label(root, text='''please choose where to assign these ability scores''')
assign_scores_label.grid(row=1, column=3)
AS_1_label = Label(root, text=AS_1)
AS_1_label.grid(row=2, column=2)
AS_2_label = Label(root, text=AS_2)
AS_2_label.grid(row=2, column=3)
AS_3_label = Label(root, text=AS_3)
AS_3_label.grid(row=2, column=4)
AS_4_label = Label(root, text=AS_4)
AS_4_label.grid(row=3, column=2)
AS_5_label = Label(root, text=AS_5)
AS_5_label.grid(row=3, column=3)
AS_6_label = Label(root, text=AS_6)
AS_6_label.grid(row=3, column=4)
Strength = Entry(root)
Strength.grid(row=4, column=2)
Strength.insert(0, "STR")
Dexterity = Entry(root)
Dexterity.grid(row=4, column=3)
Dexterity.insert(0, "DEX")
Constitution = Entry(root)
Constitution.grid(row=4, column=4)
Constitution.insert(0, "CON")
Intelligence = Entry(root)
Intelligence.grid(row=5, column=2)
Intelligence.insert(0, "INT")
Wisdom = Entry(root)
Wisdom.grid(row=5, column=3)
Wisdom.insert(0, "WIS")
Charisma = Entry(root)
Charisma.grid(row=5, column=4)
Charisma.insert(0, "CHA")

start_screen_label = Label(root, text='''Hi! I'm The Non Player Creator
Welcome! I'm gonna help you create an NPC for your game! ''')
start_screen_label.grid(row=1, column=1)

name_button = Button(root, text="Give Them a Name", command=nameclick, padx=50)
name_button.grid(row=5, column=1)

root.mainloop()
#where do I go from here??? addendum:gosh how wild this got before v1.0
#V1.0 complete get out the champagne
